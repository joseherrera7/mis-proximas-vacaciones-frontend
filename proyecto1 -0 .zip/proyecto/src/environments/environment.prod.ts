export const environment = {
  production: true,
  server: 'https://api.bing.microsoft.com/',
  clave1: '7de0481354394428b4b9e30bdc9f759a',
  clave2: '375c1ed0a7ab47cf926a7769477254eb'
};
